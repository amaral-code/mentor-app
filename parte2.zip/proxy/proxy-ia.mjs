// Proxy mesma-origem (dev/teste): serve o dist/ e encaminha /ia/* ao worker,
// injetando o API_TOKEN no servidor. O celular nunca toca em workers.dev,
// então adblock/DNS não têm o que bloquear. Token via env, nunca no código.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const PORT = 4174;
const DIST = '/workspaces/mentor-app/dist';
const WORKER = 'https://midnight-mentor-ia.miguelmito-amaral.workers.dev';
const API_TOKEN = process.env.IA_PROXY_TOKEN || '';
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.webmanifest': 'application/manifest+json' };

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/ia/')) {
      const destino = WORKER + url.pathname.slice(3) + url.search;
      const corpo = await new Promise((resolve) => {
        const partes = []; req.on('data', (c) => partes.push(c)); req.on('end', () => resolve(Buffer.concat(partes)));
      });
      const r = await fetch(destino, {
        method: req.method,
        headers: { 'Content-Type': req.headers['content-type'] || 'application/json', Authorization: `Bearer ${API_TOKEN}` },
        body: ['GET', 'HEAD'].includes(req.method) ? undefined : corpo,
      });
      const buf = Buffer.from(await r.arrayBuffer());
      res.writeHead(r.status, { 'Content-Type': r.headers.get('content-type') || 'application/json' });
      res.end(buf);
      return;
    }
    let arq = path.join(DIST, url.pathname === '/' ? 'index.html' : url.pathname.slice(1));
    if (!fs.existsSync(arq) || fs.statSync(arq).isDirectory()) arq = path.join(DIST, 'index.html');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(arq)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    fs.createReadStream(arq).pipe(res);
  } catch (e) { res.writeHead(500); res.end('erro'); }
});
server.listen(PORT, () => console.log('proxy+estatico na porta', PORT));
